﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectHotel_UAS_PAD
{
    internal class Kamar
    {
        public DataTable GetData()
        {
            DataTable dt = new DataTable();

            return dt;
        }
    }
}
